//protractor.conf.js
exports.config = {
  //chromeDriver: '../node_modules/protractor/node_modules/webdriver-manager/selenium/chromedriver_79.0.3945.36',
    directConnect : true,
    getPageTimeout: 50000,
    allScriptsTimeout: 50000,
    framework: 'custom', 
    // path relative to the current config file
    frameworkPath: require.resolve('protractor-cucumber-framework'),
    capabilities: {
      'browserName': 'chrome',
      chromeOptions: {
        args: ['--no-sandbox']
      },
    },
  
    // Spec patterns are relative to this directory.
    specs: [
      'tests/cucumber/Feature/*.feature'
    ],
  
    cucumberOpts: {
      require: 'tests/cucumber/Step_Definition/stepDefinition.js',
      tags: false,
      // format: ['pretty'],
      profile: false,
      'no-source': true
    },
    onPrepare: function () {
      browser.manage().window().maximize(); // maximize the browser before executing the feature files
    }
  };